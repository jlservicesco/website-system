JL Services Website (Screenshot Style)

- Built to match the "dark header + storm hero + orange buttons" mockup.
- Edit contact info in the HTML files (search for (###) ###-#### and youremail@domain.com).
- Images are in assets/img:
  - hero.jpg (homepage header background)
  - install.jpg (generator install photo)
  - remodel.jpg (placeholder — replace with your remodeling photo)
  - logo.png (your current logo file; replace with transparent PNG when ready)

Hosting:
- Netlify: drag-and-drop the folder contents (or ZIP contents) into Netlify Deploy.
- Any web host: upload all files and folders into the public root.

